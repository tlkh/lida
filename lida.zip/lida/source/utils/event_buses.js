/*******************************************************************************
* EVENT BUSES
*******************************************************************************/
const annotationAppEventBus = new Vue();

const textSplitterEventBus = new Vue();

const allDialoguesEventBus = new Vue();


// EOF
